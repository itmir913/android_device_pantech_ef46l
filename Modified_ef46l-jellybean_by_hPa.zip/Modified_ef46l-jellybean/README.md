Modified_ef46l
==============

Modified sources in CyanogenMod10 for IM-A830L (SKY Vega Racer2)
